package com.minecraftdemo;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.Chest;
import org.bukkit.entity.FallingBlock;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPhysicsEvent;
import org.bukkit.event.block.BlockPistonRetractEvent;
import org.bukkit.event.entity.EntityChangeBlockEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

public class AutoTreeChopper extends JavaPlugin implements Listener {

    @Override
    public void onEnable() {
        getServer().getPluginManager().registerEvents(this, this);
    }

    @EventHandler
    public void onBlockBreak(BlockBreakEvent event) {
        Block block = event.getBlock();
        if (block.getType() == Material.CHEST && block.getWorld().getBlockAt(block.getLocation().add(0, 1, 0)).getType() == Material.DIAMOND_BLOCK) {
            // Check if the chest is on top of a diamond block
            activateTreeChopper(block);
        }
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        Inventory inventory = event.getInventory();
        if (inventory.getHolder() instanceof Chest && inventory.firstEmpty() == -1) {
            // Chest is full, deactivate tree chopper
            deactivateTreeChopper((Chest) inventory.getHolder());
        }
    }

    @EventHandler
    public void onBlockPhysics(BlockPhysicsEvent event) {
        // Prevent the chest from falling when tree chopping is active
        if (event.getBlock().getType() == Material.CHEST) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onEntityChangeBlock(EntityChangeBlockEvent event) {
        if (event.getEntity() instanceof FallingBlock) {
            // Prevent falling blocks during tree chopping
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onPistonRetract(BlockPistonRetractEvent event) {
        // Prevent pistons from retracting blocks when tree chopping is active
        if (event.getBlocks().stream().anyMatch(block -> block.getType() == Material.CHEST)) {
            event.setCancelled(true);
        }
    }

    private void activateTreeChopper(Block chestBlock) {
        Chest chest = (Chest) chestBlock.getState();
        Inventory chestInventory = chest.getInventory();

        // Get the material of the bit block (diamond, emerald, gold)
        Material bitMaterial = chestBlock.getRelative(0, 1, 0).getType();

        // Implement tree chopping logic here
        chopTree(chestBlock.getLocation(), bitMaterial);

        // Notify the player when the chest is full
        if (isChestFull(chestInventory)) {
            deactivateTreeChopper(chest);
        }
    }

    private void chopTree(Location chestLocation, Material bitMaterial) {
        World world = chestLocation.getWorld();
        int x = chestLocation.getBlockX();
        int y = chestLocation.getBlockY();
        int z = chestLocation.getBlockZ();

        // Define chopping speeds and effects based on bit material
        int choppingDelay;
        Particle choppingParticle;

        switch (bitMaterial) {
            case DIAMOND_BLOCK:
                choppingDelay = 20;
                choppingParticle = Particle.CRIT;
                break;
            case EMERALD_BLOCK:
                choppingDelay = 40;
                choppingParticle = Particle.VILLAGER_HAPPY;
                break;
            case GOLD_BLOCK:
                choppingDelay = 60;
                choppingParticle = Particle.FLAME;
                break;
            default:
                choppingDelay = 40;
                choppingParticle = Particle.VILLAGER_HAPPY;
                break;
        }

        for (int i = y; i >= 0; i--) {
            Block block = world.getBlockAt(x, i, z);
            Material blockType = block.getType();

            if (isLog(blockType)) {
                block.breakNaturally();

                // Emit particle effects
                world.spawnParticle(choppingParticle, block.getLocation().add(0.5, 0.5, 0.5), 10);

                // You may want to add the log to the chest inventory
                // For now, we'll assume logs are dropped as items
                world.dropItemNaturally(chestLocation, new ItemStack(blockType));

                // Delay between chopping blocks to simulate chopping speed
                try {
                    Thread.sleep(choppingDelay);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            } else {
                break;
            }
        }
    }

    private boolean isLog(Material material) {
        // Check if the material is a log
        return material == Material.OAK_LOG ||
                material == Material.SPRUCE_LOG ||
                material == Material.BIRCH_LOG ||
                material == Material.JUNGLE_LOG ||
                material == Material.ACACIA_LOG ||
                material == Material.DARK_OAK_LOG;
    }

    private boolean isChestFull(Inventory inventory) {
        return inventory.firstEmpty() == -1;
    }

    private void deactivateTreeChopper(Chest chest) {
        // Deactivate tree chopper logic here
        // Stop searching for trees and notify the player

        Location chestLocation = chest.getLocation();
        World world = chestLocation.getWorld();

        // Retrieve the online players
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (player.getWorld().equals(world) && player.getLocation().distance(chestLocation) < 50) {
                // Adjust the distance as needed to fit your scenario
                player.sendMessage("Tree chopper deactivated. Chest is full.");
            }
        }
    }
}

