# Auto Tree Chopper Plugin

## Overview

This Minecraft Spigot plugin introduces an Auto Tree Chopper, a mechanized tree-chopping machine with unique behaviors and interactions. The plugin allows players to construct a machine with different materials, each providing varying chopping speeds and bonus features.

## Setup

### Machine Construction

1. **Base:** Place a diamond, emerald, or gold block (“bits”) on the ground.
2. **Top:** Place a chest on top of the bit block.

### Control Mechanism

- If a chest is on top of a bit block, the machine is activated.
- The machine deactivates when the chest is full.

## Features

### Chopping Speed Variation

- **Diamond Block:** Fastest chopping speed.
- **Emerald Block:** Moderate speed with a unique bonus feature (particle effects).
- **Gold Block:** Slower speed with higher yield or special effect.

### Special Blocks Interaction

- **Ferns/Mushrooms/Flowers:** The machine breaks apart upon contact.
- **Water:** Floats and continues operating.
- **Sponge/Ice:** Triggers specific behaviors or effects when encountered.

## Usage

1. Build the machine following the setup instructions.
2. Activate the machine by placing a chest on the bit block.
3. The machine will automatically detect and chop down trees in its path.
4. A notification will be sent when the chest is full, and the machine will deactivate.

### Time taken to complete this code: 
3 hours

### Challanges